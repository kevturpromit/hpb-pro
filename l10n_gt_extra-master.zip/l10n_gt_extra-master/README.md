# l10n_gt_extra
Modulo de Odoo para la contabilidad de Guatemala
